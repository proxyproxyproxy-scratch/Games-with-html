 elements.time = {
    color: "#006e05",
    behavior: behaviors.GAS,
    category: "gases",
    state: "gas",
    density: 10,
}; 
