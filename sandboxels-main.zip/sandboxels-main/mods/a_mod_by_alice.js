logMessage("a_mod_by_alice.js is deprecated. Please remove this mod from your mod list.")
